//
//  ViewController.swift
//  Pokemon
//
//  Created by Brindha Kannan on 28/07/21.
//

import UIKit

class ViewController: UIViewController,      webserviceDelegate,UISearchBarDelegate, UISearchDisplayDelegate{
    
    func getresponse(response: Data) {
        
        do {
            let jsonObj = try JSONSerialization.jsonObject(with: response, options: .allowFragments)
            print("jsonObj------------>",jsonObj)
            
            
            pokeMon_data = try JSONDecoder().decode(pokeMon_Base.self, from: response as Data)
            
//            DispatchQueue.main.async {
//                self.tbl_parser.reloadData()
//            }
            
            print(pokeMon_data?.results!.count ?? "")
            DispatchQueue.main.async {
                self.myActivityIndicator.stopAnimating()
// UserDefaults.standard.set(self.pokeMon_data, forKey:"poke")
                self.drawTbl()
 
            }
            
            Data_pokemonName = (pokeMon_data?.results!)!
            if pokeMon_data != nil{
                
                all_pokeMonData?.append(pokeMon_data!)
                print("All pokemon",all_pokeMonData)
            }
            
//            get_pokemonNama()
        }
        catch{
            print(error)
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
//        let foundItems = Data_pokemonName.filter { $0.itemName == "name" }


//        filtered = Data_pokemonName.filter({ (text) -> Bool in
//                    let tmp: NSString = text
//                    let range = tmp.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
//                    return range.location != NSNotFound
//                })
//                if(filtered.count == 0){
//                    searchActive = false;
//                } else {
//                    searchActive = true;
//                }
        
        filtered = Data_pokemonName.filter { $0.name?.hasPrefix(searchText) ?? true }
            print("filterr---->",filtered)

            self.tbl_Pokemon.reloadData()
    }
    
    func get_pokemonNama(){
        
        self.serviceCall.delegate = self
        self.serviceCall.serviceCall(urlString : pokeMon_data?.next ?? "")
        print("NEXT---->")
    }
    
    var lbl_title : UILabel!
    var search_Bar = UISearchBar()
    var tbl_Pokemon : UITableView!
    
    var serviceCall =  webservice()
    var pokeMon_data : pokeMon_Base?
    var all_pokeMonData : [pokeMon_Base]?
    let myActivityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.gray)
    
    var searchActive : Bool = false
    var Data_pokemonName = [Results]()
    var filtered = [Results]()


    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        myActivityIndicator.center = view.center
        myActivityIndicator.hidesWhenStopped = false
        
        view.addSubview(myActivityIndicator)
        DispatchQueue.main.asyncAfter(deadline: .now() + 50.0){
            self.myActivityIndicator.startAnimating()

        }
        self.serviceCall.delegate = self
        self.serviceCall.serviceCall(urlString : "https://pokeapi.co/api/v2/pokemon/")
        
        drawUI()
        drawTbl()
    }
    
    func drawUI(){
        
        lbl_title = UILabel()
        lbl_title.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(lbl_title)
        lbl_title.setViewConstraints(top: view.safeAreaLayoutGuide.topAnchor, left: view.safeAreaLayoutGuide.leadingAnchor, right: view.safeAreaLayoutGuide.trailingAnchor, bottom: nil, padding: UIEdgeInsets(top: 20, left: 20, bottom: 0, right: -20), size: CGSize(width: 0, height: 30))
        lbl_title.text = "WELCOME TO POKEMON"
        lbl_title.textAlignment = .center
        
        search_Bar = UISearchBar()
        view.addSubview(search_Bar)
        search_Bar.translatesAutoresizingMaskIntoConstraints = false
        search_Bar.setViewConstraints(top: lbl_title.bottomAnchor, left: view.leadingAnchor, right: view.trailingAnchor, bottom: nil, padding: UIEdgeInsets(top: 20, left: 20, bottom: 0, right: -20), size: CGSize(width: 0, height: 30))
        search_Bar.delegate = self
        search_Bar.autocapitalizationType = .none

    }
    
    func drawTbl(){
        
        tbl_Pokemon = UITableView()
        view.addSubview(tbl_Pokemon)
        tbl_Pokemon.translatesAutoresizingMaskIntoConstraints = false
        tbl_Pokemon.setViewConstraints(top: search_Bar.bottomAnchor, left: search_Bar.leadingAnchor, right: search_Bar.trailingAnchor, bottom: view.safeAreaLayoutGuide.bottomAnchor, padding: UIEdgeInsets(top: 10, left: 0, bottom: -10, right: 0), size: CGSize(width: 0, height: 0))
        tbl_Pokemon.rowHeight = UITableView.automaticDimension
        tbl_Pokemon.estimatedRowHeight = 80
        tbl_Pokemon.register(PokeTableViewCell.self, forCellReuseIdentifier: "PokemonCell")
        tbl_Pokemon.layer.cornerRadius = 8
        tbl_Pokemon.layer.masksToBounds = true

//        tbl_Pokemon.shadowLayer.layer.masksToBounds = false
//        tbl_Pokemon.shadowLayer.layer.shadowOffset = CGSizeMake(0, 0)
//        tbl_Pokemon.shadowLayer.layer.shadowColor = UIColor.blackColor().CGColor
//        tbl_Pokemon.shadowLayer.layer.shadowOpacity = 0.23
//        tbl_Pokemon.shadowLayer.layer.shadowRadius = 4
        tbl_Pokemon.delegate = self
        tbl_Pokemon.dataSource = self
        tbl_Pokemon.reloadData()
        
    }
}

class PokeTableViewCell : UITableViewCell{
    
    var view_base: UIView!
    var img_poke: UIImageView!
    var lbl_poke: UILabel!

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        backgroundColor = UIColor.clear
        selectionStyle = .none

        view_base = UIView()
        self.addSubview(view_base)
        view_base.translatesAutoresizingMaskIntoConstraints = false
        view_base.setViewConstraints(top: self.topAnchor, left: self.leadingAnchor, right: self.trailingAnchor, bottom: self.bottomAnchor, padding: UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0), size: CGSize(width: 0, height: 0))

        img_poke = UIImageView()
        self.addSubview(img_poke)
        img_poke.translatesAutoresizingMaskIntoConstraints = false
        img_poke.setViewConstraints(top: view_base.topAnchor, left: view_base.leadingAnchor, right: nil, bottom: nil, padding: UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0), size: CGSize(width: 30, height: 30))

        lbl_poke = UILabel()
        self.addSubview(lbl_poke)
        lbl_poke.translatesAutoresizingMaskIntoConstraints = false
        lbl_poke.setViewConstraints(top: nil, left: img_poke.trailingAnchor, right: nil, bottom: nil, padding: UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 0), size: CGSize(width: 0, height: 0))
        lbl_poke.centerYAnchor.constraint(equalTo: img_poke.centerYAnchor).isActive = true
        lbl_poke.numberOfLines = 0

    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filtered.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PokemonCell", for: indexPath) as! PokeTableViewCell
        cell.lbl_poke.text = filtered[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var pokeDetailVC = pokeDetailViewController()
        pokeDetailVC.Data_pokemon = filtered[indexPath.row]
        pokeDetailVC.modalPresentationStyle = .fullScreen
        self.present(pokeDetailVC, animated:true, completion:nil)
    }
}


extension UIView
{
    func setViewConstraints(top:NSLayoutYAxisAnchor?,left:NSLayoutXAxisAnchor?,right:NSLayoutXAxisAnchor?,bottom:NSLayoutYAxisAnchor?, padding:UIEdgeInsets = .zero,size:CGSize = .zero ) -> Void {
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
        
        if let top = top
        {
            topAnchor.constraint(equalTo: top, constant: padding.top).isActive=true
        }
        
        if let bottom = bottom
        {
            bottomAnchor.constraint(equalTo: bottom, constant: padding.bottom).isActive=true
        }
        if let left = left
        {
            leadingAnchor.constraint(equalTo: left, constant: padding.left).isActive=true
        }
        if let right = right
        {
            trailingAnchor.constraint(equalTo: right, constant: padding.right).isActive=true
        }
        
        if size.width>0 {
            widthAnchor.constraint(equalToConstant: size.width).isActive=true
        }
        
        if size.height>0
        {
            heightAnchor.constraint(equalToConstant: size.height).isActive=true
        }
    }
}

