//
//  pokeDetailViewController.swift
//  Pokemon
//
//  Created by Brindha Kannan on 28/07/21.
//

import UIKit

class pokeDetailViewController: UIViewController, webserviceDelegate {
    
    func getresponse(response: Data) {
        
    }
    
    
    var view_base: UIView!
    var btn_back : UIButton!
    var img_poke: UIImageView!
    var lbl_pokeName: UILabel!
    var lbl_pokeNameVal: UILabel!

    
    var Data_pokemon : Results?
    var serviceCall =  webservice()


    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        self.serviceCall.delegate = self
        self.serviceCall.serviceCall(urlString : Data_pokemon?.url ?? "")
        drawUI()
    }
    
    func drawUI(){
        
        btn_back = UIButton()
        view.addSubview(btn_back)
        btn_back.translatesAutoresizingMaskIntoConstraints = false
        btn_back.setViewConstraints(top: view.safeAreaLayoutGuide.topAnchor, left: view.leadingAnchor, right: nil, bottom: nil, padding: UIEdgeInsets(top: 15, left: 10, bottom: 0, right: 0), size: CGSize(width: 35, height: 35))
        btn_back.setImage(UIImage(named: "back"), for: .normal)
        btn_back.addTarget(self, action: #selector(backClk), for: .touchUpInside)
        
        lbl_pokeName = UILabel()
        view.addSubview(lbl_pokeName)
        lbl_pokeName.translatesAutoresizingMaskIntoConstraints = false
        lbl_pokeName.setViewConstraints(top: btn_back.bottomAnchor, left: view.leadingAnchor, right: nil, bottom: nil, padding: UIEdgeInsets(top: 10, left: 10, bottom: 0, right: 0), size: CGSize(width: 60, height: 30))
        lbl_pokeName.text = "Name :"
        lbl_pokeName.textAlignment = .center

//        lbl_pokeName.centerYAnchor.constraint(equalTo: img_poke.centerYAnchor).isActive = true
        
        lbl_pokeNameVal = UILabel()
        view.addSubview(lbl_pokeNameVal)
        lbl_pokeNameVal.translatesAutoresizingMaskIntoConstraints = false
        lbl_pokeNameVal.setViewConstraints(top: lbl_pokeName.topAnchor, left: lbl_pokeName.trailingAnchor, right: view.trailingAnchor, bottom: lbl_pokeName.bottomAnchor, padding: UIEdgeInsets(top: 0, left: 20, bottom: 0, right: -10), size: CGSize(width: 0, height: 0))
        lbl_pokeNameVal.text = Data_pokemon?.name
        lbl_pokeNameVal.textAlignment = .center
    }
    
    @objc func backClk(){
        
        self.dismiss(animated: true, completion: nil)
    }

}
