/* 
Copyright (c) 2021 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Versions : Codable {
	let generation-i : Generation-i?
	let generation-ii : Generation-ii?
	let generation-iii : Generation-iii?
	let generation-iv : Generation-iv?
	let generation-v : Generation-v?
	let generation-vi : Generation-vi?
	let generation-vii : Generation-vii?
	let generation-viii : Generation-viii?

	enum CodingKeys: String, CodingKey {

		case generation-i = "generation-i"
		case generation-ii = "generation-ii"
		case generation-iii = "generation-iii"
		case generation-iv = "generation-iv"
		case generation-v = "generation-v"
		case generation-vi = "generation-vi"
		case generation-vii = "generation-vii"
		case generation-viii = "generation-viii"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		generation-i = try values.decodeIfPresent(Generation-i.self, forKey: .generation-i)
		generation-ii = try values.decodeIfPresent(Generation-ii.self, forKey: .generation-ii)
		generation-iii = try values.decodeIfPresent(Generation-iii.self, forKey: .generation-iii)
		generation-iv = try values.decodeIfPresent(Generation-iv.self, forKey: .generation-iv)
		generation-v = try values.decodeIfPresent(Generation-v.self, forKey: .generation-v)
		generation-vi = try values.decodeIfPresent(Generation-vi.self, forKey: .generation-vi)
		generation-vii = try values.decodeIfPresent(Generation-vii.self, forKey: .generation-vii)
		generation-viii = try values.decodeIfPresent(Generation-viii.self, forKey: .generation-viii)
	}

}